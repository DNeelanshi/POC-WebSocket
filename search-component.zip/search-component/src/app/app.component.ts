import { Component } from '@angular/core';
import { WebSocketAPI } from './WebSocketAPI';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular8-springboot-websocket';

  webSocketAPI: WebSocketAPI;
  name: string;
  greeting:any;
  
  ngOnInit() {
    this.webSocketAPI = new WebSocketAPI(new AppComponent());
    this.webSocketAPI._connect();
  }

  connect(){
   
  }

  disconnect(){
    this.webSocketAPI._disconnect();
  }

  sendMessage(){
    this.webSocketAPI._send(this.name);
  }

  handleMessage(message){
 
     this.greeting = JSON.parse(message).content;
     if(this.greeting.length != 0){
      alert(this.greeting);
     }
    
  }

}
